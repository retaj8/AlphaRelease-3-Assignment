<?php
session_start();
include 'conn_cmt.php';
include 'User.php';

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $error_message = "يرجى إدخال اسم المستخدم وكلمة المرور";
    } else {
        $user = new User($conn);
        $role = $user->login($username, $password);

        if ($role) {
            switch ($role) {
                case 'admin':
                    header("Location: dashboard.php");
                    break;
                case 'leader':
                    header("Location: add_project.php");
                    break;
                case 'student':
                    header("Location: add_project.php");
                    break;
                default:
                    $error_message = "دور غير معروف";
            }
            exit();
        } else {
            $error_message = "اسم المستخدم أو كلمة المرور غير صحيحة";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>تسجيل الدخول</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; /* خلفية هادئة */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .card {
            max-width: 450px;
            width: 100%;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center">
        <div class="card bg-white">
            <h2 class="text-center text-secondary">تسجيل الدخول</h2>
            
            <!-- عرض رسالة الخطأ إن وجدت -->
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger text-center"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">اسم المستخدم</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">كلمة المرور</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-secondary w-100">تسجيل الدخول</button>
            </form>
            
            <p class="text-center mt-3">
                <a href="register.php" class="text-decoration-none">إنشاء حساب جديد</a>
            </p>
        </div>
    </div>
</body>
</html>
