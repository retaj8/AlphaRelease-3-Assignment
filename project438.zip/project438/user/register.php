<?php
include 'conn_cmt.php';
include 'User.php';

$error_message = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = trim($_POST['password']);
    $email = htmlspecialchars(trim($_POST['email']));
    

    if (empty($username) || empty($password) || empty($email) ) {
        $error_message = "⚠️ يرجى إدخال جميع البيانات!";
    } else {
        $user = new User($conn);
        $message = $user->register($username, $password, $email);

        if (strpos($message, "⚠️") !== false) {
            $error_message = $message; // إذا كان هناك خطأ
        } else {
            $success_message = $message; // نجاح التسجيل
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إنشاء حساب جديد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
    <div class="container">
        <div class="card shadow p-4">
            <h2 class="text-center">إنشاء حساب جديد</h2>
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">اسم المستخدم</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">كلمة المرور</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">البريد الإلكترونى</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">إنشاء الحساب</button>
            </form>
            <p class="text-center mt-3"><a href="login.php">الرجوع إلى تسجيل الدخول</a></p>
        </div>
    </div>
</body>
</html>